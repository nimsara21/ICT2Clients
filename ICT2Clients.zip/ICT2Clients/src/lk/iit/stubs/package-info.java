@javax.xml.bind.annotation.XmlSchema(namespace = "http://ict2webapplicationtry.ict.iit.lk/")
package lk.iit.stubs;
